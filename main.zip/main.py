import json
import yaml
import logging
import boto3
import urllib.parse

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class GetFIleS3:
  def __init__(self):
    logger.info("Getting yaml file downloaded from bucket for which event being triggered")
    self.s3_client = boto3.client('s3')


  def GetObject(self, event):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    try:
      response = self.s3_client.get_object(Bucket=bucket, Key=key)
      print("CONTENT TYPE: " + response['ContentType'])
      return bucket, key
    except Exception as e:
      print(e)
      print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
      raise e

class YamlParser:
  def __init__(self):
    logger.info("Parsing yaml file to json")

  def ParseYaml(self, key):
    try:
        source_file = open(key, "r")
        source_content = yaml.safe_load(source_file)
        source_file.close()
    except FileNotFoundError:
        print("FIle not found")
    output = json.dumps(source_content)
    try:
      target_file = open(key.split('.')[0] + "json", "w")
      target_file.write(output)
      target_file.close()
    except:
      print("File not opening")
      

class UploadFileS3:
  def __init__(self):
    logger.info("Getting json file uploaded to bucket after conversion")
    self.s3_client = boto3.client('s3')


  def PutObject(self, bucket, key):
    try:
      response = self.s3_client.put_object(Bucket=bucket, Key=key)
      print("CONTENT TYPE: " + response['ContentType'])
      return response['ContentType']
    except Exception as e:
      print(e)
      print('Error putting object {} into bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
      raise e
    logger.info(response['ContentType'])


def lambda_handler(event, context):
  logger.info(event)
  FileDownlaod = GetFIleS3()
  bucket, key = FileDownlaod.GetObject(event)
  FileParser = YamlParser()
  FileParser.ParseYaml(key)
  FileUpload = UploadFileS3()
  response = FileUpload.PutObject(bucket, key.split('.')[0] + "json")
  print(response)