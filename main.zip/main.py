import json
import yaml
import logging
import boto3
import urllib.parse
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class GetFIleS3:
  def __init__(self):
    logger.info("Getting yaml file downloaded from bucket for which event being triggered")
    self.s3_client = boto3.client('s3')


  def GetObject(self, event):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    Filename = str(key)
    try:
      response = self.s3_client.download_file(bucket, key, "/tmp/" + Filename)
      logger.info("Downloaded YAML file from s3 bucket for which event being triggered")
      return bucket, key
    except Exception as e:
      print(e)
      print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
      raise e

class YamlParser:
  def __init__(self):
    logger.info("Parsing downloaded yaml file to json")

  def ParseYaml(self, key):
    try:
        source_file = open("/tmp/" + str(key), "r")
        source_content = yaml.safe_load(source_file)
        source_file.close()
    except FileNotFoundError:
        print("File not found")
    output = json.dumps(source_content)
    Filename = str(key.split('.')[0]) + ".json"
    try:
      target_file = open("/tmp/" + Filename, "w")
      target_file.write(output)
      target_file.close()
    except IOError:
      print("File not opening")
    logger.info("Parsed downloaded yaml file to json")

class UploadFileS3:
  def __init__(self):
    logger.info("Getting json file uploaded to bucket after conversion")
    self.s3_client = boto3.client('s3')


  def PutObject(self, bucket, key):
    FileKey=str(key.split('.')[0]) + ".json"
    try:
      response = self.s3_client.upload_file(Filename="/tmp/" + FileKey, Bucket=bucket, Key=FileKey)
    except Exception as e:
      print(e)
      print('Error putting object {} into bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
      raise e


def lambda_handler(event, context):
  logger.info(event)
  FileDownlaod = GetFIleS3()
  bucket, key= FileDownlaod.GetObject(event)
  FileParser = YamlParser()
  FileParser.ParseYaml(key)
  FileUpload = UploadFileS3()
  response = FileUpload.PutObject(bucket, key)